let stopMediaPlayback;
let youtubeApiPromise;

function loadYouTubeApi() {
  if (window.YT?.Player) return Promise.resolve(window.YT);
  if (!youtubeApiPromise) {
    youtubeApiPromise = new Promise(resolve => {
      const script = document.createElement("script");
      script.src = "https://www.youtube.com/iframe_api";
      script.async = true;
      const finish = api => {
        clearTimeout(timeout);
        resolve(api);
      };
      const timeout = setTimeout(() => finish(null), 8000);
      window.onYouTubeIframeAPIReady = () => finish(window.YT);
      script.addEventListener("error", () => finish(null), {once: true});
      document.head.append(script);
    });
  }
  return youtubeApiPromise;
}

function setupNativePlayback(app, watch) {
  app.querySelectorAll("video[data-autoplay-in-view]").forEach(video => {
    let visible = false;
    let pausedByVisitor = false;
    video.addEventListener("pause", () => {
      if (visible) pausedByVisitor = true;
    });
    video.addEventListener("play", () => {
      if (visible) pausedByVisitor = false;
    });
    watch(video, .2, (inView, autoplay) => {
      visible = inView;
      if (!visible && !video.paused) {
        video.pause();
      } else if (autoplay && video.paused && !video.ended && video.muted && !pausedByVisitor) {
        video.play().catch(() => {});
      }
    });
  });

  app.querySelectorAll("[data-wix-video]").forEach(wrapper => {
    const video = wrapper.querySelector("video");
    const showPoster = () => {
      const poster = document.createElement("img");
      poster.src = video.poster;
      poster.alt = "";
      video.replaceWith(poster);
      wrapper.querySelector(".vsl-fallback").hidden = false;
    };
    video.addEventListener("error", showPoster, {once: true});
    if (video.error) showPoster();
  });
}

function setupClosingAnimation(app, watch) {
  const button = app.querySelector("[data-case-study-preview]");
  if (!button) return;

  const image = button.closest("figure").querySelector("img");
  const playing = () => image.getAttribute("src") === SITE_CONFIG.caseStudyAnimationUrl;
  let pausedByVisitor = false;
  let unavailable = false;
  const setPlaying = (active) => {
    if (playing() === active) return;
    image.setAttribute("src", active ? SITE_CONFIG.caseStudyAnimationUrl : caseStudyPoster);
    button.textContent = active ? "Pause preview" : "Play preview";
  };
  image.addEventListener("error", () => {
    if (!playing()) return;
    unavailable = true;
    setPlaying(false);
  });
  button.addEventListener("click", () => {
    pausedByVisitor = playing();
    setPlaying(!pausedByVisitor);
  });
  watch(image, .55, (visible, autoplay) => {
    if (!visible) setPlaying(false);
    else if (autoplay && !pausedByVisitor && !unavailable) setPlaying(true);
  });
}

function setupYouTubePlayback(app, watch) {
  const clips = [...app.querySelectorAll("[data-youtube-id]")].map(button => ({
    button,
    visible: false,
    present: false,
    skipAutoplay: false,
  }));
  let active;
  let apiUnavailable = false;

  const stop = () => {
    if (!active) return;
    const {clip, frame, player} = active;
    active = null;
    player?.destroy();
    frame.remove();
    clip.button.hidden = false;
  };

  function refresh() {
    if (active) {
      const inView = active.automatic ? active.clip.visible : active.clip.present;
      if (!inView || (active.automatic && motionPreference.matches)) stop();
    }
    if (document.hidden || motionPreference.matches || apiUnavailable || (active && !active.ended)) return;
    const next = clips.find(clip => clip.visible && !clip.skipAutoplay);
    if (next) start(next, true);
  }

  function start(clip, automatic) {
    stop();
    const frame = document.createElement("iframe");
    const source = new URL(`https://www.youtube.com/embed/${clip.button.dataset.youtubeId}`);
    source.searchParams.set("enablejsapi", "1");
    source.searchParams.set("playsinline", "1");
    if (!automatic) source.searchParams.set("autoplay", "1");
    frame.src = source.href;
    frame.title = clip.button.dataset.videoTitle;
    frame.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen";
    frame.allowFullscreen = true;
    clip.button.hidden = true;
    clip.button.after(frame);
    if (!automatic) frame.focus({preventScroll: true});
    const session = {clip, frame, automatic, ended: false, started: false};
    active = session;

    loadYouTubeApi().then(api => {
      if (active !== session) return;
      if (!api) {
        apiUnavailable = true;
        if (automatic) stop();
        return;
      }
      session.player = new api.Player(frame, {
        events: {
          onReady({target}) {
            if (active === session && automatic && clip.visible && !motionPreference.matches) {
              target.mute();
              target.playVideo();
            }
          },
          onStateChange({data}) {
            if (active !== session) return;
            if (data === api.PlayerState.PLAYING) {
              session.started = true;
              session.ended = false;
            } else if (data === api.PlayerState.ENDED) {
              clip.skipAutoplay = true;
              session.ended = true;
              refresh();
            } else if (data === api.PlayerState.PAUSED && session.started) {
              clip.skipAutoplay = true;
            }
          },
          onError() {
            if (active !== session) return;
            clip.skipAutoplay = true;
            stop();
            refresh();
          },
          onAutoplayBlocked() {
            if (active === session && automatic) clip.skipAutoplay = true;
          },
        },
      });
    });
  }

  clips.forEach(clip => {
    watch(clip.button.parentElement, .6, (visible, autoplay, present) => {
      clip.visible = visible;
      clip.present = present;
    });
    clip.button.addEventListener("click", () => start(clip, false));
  });
  return {refresh, stop};
}

function setupVideoPlayers(app) {
  stopMediaPlayback?.();
  const tracked = new Map();
  const listeners = new AbortController();
  const watch = (element, threshold, update) => {
    tracked.set(element, {threshold, update, ratio: 0});
    observer?.observe(element);
  };
  const refresh = () => {
    tracked.forEach(({threshold, update, ratio}, element) => {
      const present = !document.hidden && element.isConnected && ratio > 0;
      const visible = present && ratio >= threshold;
      update(visible, visible && !motionPreference.matches, present);
    });
    youtube.refresh();
  };
  const observer = "IntersectionObserver" in window ? new IntersectionObserver(entries => {
    entries.forEach(entry => { tracked.get(entry.target).ratio = entry.intersectionRatio; });
    refresh();
  }, {threshold: [0, .2, .55, .6]}) : null;

  setupNativePlayback(app, watch);
  setupClosingAnimation(app, watch);
  const youtube = setupYouTubePlayback(app, watch);
  document.addEventListener("visibilitychange", refresh, {signal: listeners.signal});
  motionPreference.addEventListener("change", refresh, {signal: listeners.signal});
  stopMediaPlayback = () => {
    observer?.disconnect();
    listeners.abort();
    youtube.stop();
  };
}
