const SITE_CONFIG = Object.freeze({
  schedulingUrl: "booking-preview.html",
  viralVideoUrl: "https://video.wixstatic.com/video/cdd8bd_fac5aca9905b432e9f7971a8daddd9b9/480p/mp4/file.mp4",
  testimonialVideoUrl: "https://video.wixstatic.com/video/15d6ed_ee145bddca3c4194a1a4edce396891fe/1080p/mp4/file.mp4",
  caseStudyAnimationUrl: "https://static.wixstatic.com/media/ca7be5_6e4ae823424343aaa73137fd66cb6fd9~mv2.gif",
});
