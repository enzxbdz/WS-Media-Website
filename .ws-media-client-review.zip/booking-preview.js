function showBookingPreferences() {
  const storageKey = "ws-media-booking-preferences";
  let preferences;
  try {
    const draft = sessionStorage.getItem(storageKey);
    if (!draft) return;
    sessionStorage.removeItem(storageKey);
    preferences = JSON.parse(draft);
  } catch {
    return;
  }

  const fields = ["date", "time", "goals"];
  if (!preferences || fields.some(field => typeof preferences[field] !== "string")) return;

  const details = document.getElementById("booking-preferences");
  fields.forEach(field => {
    details.querySelector(`[data-preference="${field}"]`).textContent = preferences[field];
  });
  details.hidden = false;
}

const bookingPage = new URL("booking-preview.html", document.baseURI);
const schedulingDestination = new URL(SITE_CONFIG.schedulingUrl, document.baseURI);

if (new URLSearchParams(location.search).get("loading") === "1") {
  const loadingCard = document.querySelector(".booking-loading-card");
  const result = document.getElementById("booking-preview-result");
  loadingCard.hidden = false;
  result.hidden = true;

  setTimeout(() => {
    if (schedulingDestination.href !== bookingPage.href) {
      location.replace(schedulingDestination.href);
      return;
    }

    showBookingPreferences();
    history.replaceState(null, "", bookingPage.href);
    loadingCard.hidden = true;
    result.hidden = false;
  }, 850);
} else {
  showBookingPreferences();
}
