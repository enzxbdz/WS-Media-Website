const themeStorageKey = "ws-media-theme";
const motionPreference = window.matchMedia("(prefers-reduced-motion: reduce)");

try {
  if (localStorage.getItem(themeStorageKey) === "light") {
    document.documentElement.dataset.theme = "light";
  }
} catch {
  // The theme toggle still works for the current page without storage.
}

let audienceObserver;

function setupPageEffects(app) {
  mountThemeToolbars(app);
  app.querySelectorAll(".hero-word").forEach((word, index) => {
    word.style.setProperty("--word-index", index);
  });

  audienceObserver?.disconnect();
  const audience = app.querySelector("[data-audience-loop]");
  if (!audience) return;
  audience.querySelectorAll(".audience-roles > span").forEach((word, index) => {
    word.style.setProperty("--word-index", index);
  });

  const pause = audience.querySelector(".audience-pause");
  pause.addEventListener("click", () => {
    const paused = audience.toggleAttribute("data-paused");
    pause.textContent = paused ? "Play" : "Pause";
    pause.setAttribute("aria-label", paused ? "Play rotating text" : "Pause rotating text");
  });

  if ("IntersectionObserver" in window) {
    audienceObserver = new IntersectionObserver(([entry]) => {
      audience.toggleAttribute("data-active", entry.isIntersecting);
    });
    audienceObserver.observe(audience);
  } else {
    audience.setAttribute("data-active", "");
  }
}

function syncThemeButtons(root) {
  const activeTheme = document.documentElement.dataset.theme ?? "dark";
  root.querySelectorAll("[data-theme-option]").forEach(button => {
    button.setAttribute("aria-pressed", String(button.dataset.themeOption === activeTheme));
  });
}

function mountThemeToolbars(root) {
  const template = document.getElementById("theme-toolbar");
  root.querySelectorAll("[data-theme-toolbar]").forEach(slot => {
    slot.replaceChildren(template.content.cloneNode(true));
  });
  syncThemeButtons(root);
}

function setupSiteEffects() {
  const root = document.documentElement;
  const themeColor = document.querySelector('meta[name="theme-color"]');
  const updateTheme = () => {
    syncThemeButtons(document);
    themeColor.content = root.dataset.theme === "light" ? "#fbfaf5" : "#080808";
  };

  mountThemeToolbars(document);
  document.addEventListener("click", event => {
    const option = event.target.closest("[data-theme-option]");
    if (!option) return;
    root.dataset.theme = option.dataset.themeOption;
    updateTheme();
    try {
      localStorage.setItem(themeStorageKey, root.dataset.theme);
    } catch {
      // The current theme stays applied when storage is unavailable.
    }
  });
  updateTheme();

  const progress = document.querySelector(".scroll-progress > div");
  let scrollFrame = 0;
  const updateProgress = () => {
    scrollFrame = 0;
    const page = document.scrollingElement;
    const distance = page.scrollHeight - page.clientHeight;
    const fraction = distance > 0 ? Math.min(1, Math.max(0, page.scrollTop / distance)) : 0;
    progress.style.transform = `scaleY(${fraction})`;
  };
  const scheduleProgress = () => {
    if (!scrollFrame) scrollFrame = requestAnimationFrame(updateProgress);
  };
  window.addEventListener("scroll", scheduleProgress, {passive: true});
  window.addEventListener("resize", scheduleProgress);
  if ("ResizeObserver" in window) {
    const sizeObserver = new ResizeObserver(scheduleProgress);
    sizeObserver.observe(document.getElementById("app"));
  }
  updateProgress();

  const spotlight = document.querySelector(".cursor-spotlight");
  const tiltSelector = ".why-card, .process-card, .case-card, .comparison-card";
  let tiltedCard;
  let pointerFrame = 0;
  let pointer;

  const resetTilt = () => {
    tiltedCard?.classList.remove("is-tilted");
    tiltedCard = null;
  };
  const clearPointer = () => {
    cancelAnimationFrame(pointerFrame);
    pointerFrame = 0;
    spotlight.classList.remove("is-visible");
    resetTilt();
  };
  const updatePointer = () => {
    pointerFrame = 0;
    const {x, y, card} = pointer;
    spotlight.style.transform = `translate3d(${x}px, ${y}px, 0)`;
    spotlight.classList.add("is-visible");
    if (tiltedCard !== card) resetTilt();
    if (!card?.isConnected) return;

    const rect = card.getBoundingClientRect();
    const horizontal = Math.max(-.5, Math.min(.5, (x - rect.left) / rect.width - .5));
    const vertical = Math.max(-.5, Math.min(.5, (y - rect.top) / rect.height - .5));
    card.style.setProperty("--tilt-x", `${-vertical * 9}deg`);
    card.style.setProperty("--tilt-y", `${horizontal * 9}deg`);
    card.classList.add("is-tilted");
    tiltedCard = card;
  };
  document.addEventListener("pointermove", event => {
    if (event.pointerType !== "mouse" || motionPreference.matches) return;
    pointer = {x: event.clientX, y: event.clientY, card: event.target.closest(tiltSelector)};
    if (!pointerFrame) pointerFrame = requestAnimationFrame(updatePointer);
  }, {passive: true});
  root.addEventListener("pointerleave", clearPointer);
  window.addEventListener("blur", clearPointer);
  window.addEventListener("scroll", resetTilt, {passive: true});
}
