// WS Media site content and image paths. Replace sample images with approved project assets before publishing.
const bookingUrl = new URL(SITE_CONFIG.schedulingUrl, document.baseURI);
const bookingPreviewUrl = new URL("booking-preview.html", document.baseURI);

const PHOTO={
  hero:"https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1200&q=85",
  edit:"https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&w=1000&q=85",
  social:"https://images.unsplash.com/photo-1533750349088-cd871a92f312?auto=format&fit=crop&w=1000&q=85",
  meta:"https://images.unsplash.com/photo-1558655146-9f40138edfeb?auto=format&fit=crop&w=1000&q=85",
  campaign:"https://images.unsplash.com/photo-1559028012-481c04fa702d?auto=format&fit=crop&w=1000&q=85",
  creator:"https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1000&q=85",
  studio:"https://images.unsplash.com/photo-1492619375914-88005aa9e8fb?auto=format&fit=crop&w=1000&q=85",
  workspace:"https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=85"
};
const services=[
 {slug:"video-editor",title:"Video Editor",titleEnd:"worth watching.",tag:"VIDEO EDITING",image:PHOTO.edit,summary:"Scale your video team without the hiring bottlenecks. From short-form socials to polished brand stories, we turn footage into moments that hold attention.",intro:"Premium video editing for brands and creators with a story to tell.",scope:{description:"For teams that need polished edits and a dependable creative partner.",items:["Short-form or long-form edits", "Captions and sound design", "Platform-ready exports"]},offers:["Short-form video for Reels, TikTok & Shorts","Long-form YouTube and podcast edits","Brand films, explainers & launches","Captions, sound design & platform-ready exports"]},
 {slug:"organic-content",title:"Organic Content",titleEnd:"built to connect.",tag:"ORGANIC CONTENT",image:PHOTO.social,summary:"Build trust and stay top of mind with a consistent content system made around your voice, your audience, and the way they scroll.",intro:"Content that builds a following before you ask for the sale.",scope:{description:"For brands that want a steady, recognizable presence across social channels.",items:["Content direction", "Social-first creative", "Repurposing support"]},offers:["Social content strategy & content pillars","Creator-led short-form video","Repurposing long-form into social cuts","Creative direction and publishing support"]},
 {slug:"meta-creatives",title:"Meta Creatives",titleEnd:"made to move.",tag:"PAID SOCIAL",image:PHOTO.meta,summary:"Make every campaign count with creative designed to stop the scroll, communicate clearly, and give your team more angles to test.",intro:"Ad creative built for testing, learning, and scaling.",scope:{description:"For campaigns that need fresh concepts and creative variations to test.",items:["Hook and concept development", "Video and static assets", "Creative variations"]},offers:["Hook and concept development","Video & static ad creative","Creative variations for testing","Campaign cutdowns and placements"]}
];
const caseStudies=[
 {type:"VIDEO EDITING",title:"Creator-led brand story",body:"A clear opening, confident pacing, and a strong finish turn a raw recording into an edit ready for the feed.",result:"Add verified watch-time / completion result"},
 {type:"ORGANIC CONTENT",title:"A more consistent social voice",body:"A repeatable series gives the audience a reason to come back and gives the team a format they can keep shipping.",result:"Add approved reach / engagement result"},
 {type:"META CREATIVE",title:"A campaign with room to learn",body:"Distinct creative directions give the media team fresh ways to test its message and connect with the right audience.",result:"Add verified campaign result"}
];
const TESTIMONIALS = [{"id":1,"offer":"META Machine","quote":"The new creative angles gave us clearer tests to run and helped the campaign find its message faster.","name":"Maya Reyes","role":"Growth Lead","brand":"Vela Skin Co.","result":"SAMPLE · +18% CTR","avatar":"/images/clients/client-01.jpg","initial":"MR","sample":true},{"id":2,"offer":"META Machine","quote":"We went from one tired ad to a small library of concepts our team could learn from every week.","name":"Ethan Cole","role":"Founder","brand":"Northstar Coffee","result":"SAMPLE · 3.1× ROAS","avatar":"/images/clients/client-02.jpg","initial":"EC","sample":true},{"id":3,"offer":"META Machine","quote":"The variations made it easier to see which product story actually connected with new customers.","name":"Ari Santos","role":"E-commerce Director","brand":"Form & Field","result":"SAMPLE · +27% CVR","avatar":"/images/clients/client-03.jpg","initial":"AS","sample":true},{"id":4,"offer":"META Machine","quote":"Our creative testing finally felt organized. We had fresh hooks ready before the next campaign sprint.","name":"Nina Patel","role":"Marketing Manager","brand":"Goodwell Health","result":"SAMPLE · 2× TESTS","avatar":"/images/clients/client-04.jpg","initial":"NP","sample":true},{"id":5,"offer":"Organic Content Machine","quote":"The content rhythm helped us show up consistently without making every post from scratch.","name":"Leo Tan","role":"Co-founder","brand":"Sunday Supply","result":"SAMPLE · +42% SAVES","avatar":"/images/clients/client-05.jpg","initial":"LT","sample":true},{"id":6,"offer":"Organic Content Machine","quote":"Our social feed feels like one brand now, and planning the next month takes far less back and forth.","name":"Camille Brooks","role":"Brand Director","brand":"Morrow Home","result":"SAMPLE · 4× CONSISTENCY","avatar":"/images/clients/client-06.jpg","initial":"CB","sample":true},{"id":7,"offer":"Organic Content Machine","quote":"The series format gave our audience something to come back for and our team a plan we can sustain.","name":"Jules Navarro","role":"Community Lead","brand":"Orbit Learning","result":"SAMPLE · +36% REPLIES","avatar":"/images/clients/client-07.jpg","initial":"JN","sample":true},{"id":8,"offer":"Organic Content Machine","quote":"Repurposing our longer stories into short social pieces made our ideas travel further across channels.","name":"Priya Menon","role":"Marketing Lead","brand":"Common Ground Studio","result":"SAMPLE · 12 CUTDOWNS","avatar":"/images/clients/client-08.jpg","initial":"PM","sample":true},{"id":9,"offer":"Video Editing","quote":"The edits brought a stronger opening and a cleaner pace to the videos we were already making.","name":"Noah Kim","role":"Creator & Host","brand":"The Build Notes","result":"SAMPLE · +31% WATCH TIME","avatar":"/images/clients/client-09.jpg","initial":"NK","sample":true},{"id":10,"offer":"Video Editing","quote":"We could hand over footage and get polished, platform-ready versions back without adding another hire.","name":"Isabel Cruz","role":"Content Director","brand":"Casa Verde","result":"SAMPLE · 48 OUTPUTS / MO","avatar":"/images/clients/client-10.jpg","initial":"IC","sample":true},{"id":11,"offer":"Video Editing","quote":"The team found the story in a long interview and turned it into clips people wanted to finish.","name":"Marcus Lee","role":"Podcast Producer","brand":"After Hours Podcast","result":"SAMPLE · 22 CLIPS","avatar":"/images/clients/client-11.jpg","initial":"ML","sample":true},{"id":12,"offer":"Video Editing","quote":"Captions, sound, and thoughtful pacing made our product explainers much easier to follow.","name":"Tessa Wright","role":"Creative Strategist","brand":"Brightpath Apps","result":"SAMPLE · 44 EXPORTS","avatar":"/images/clients/client-12.jpg","initial":"TW","sample":true},{"id":13,"offer":"Media Buying","quote":"We had a more consistent view of campaign learning and the next creative tests to prioritize.","name":"Omar Haddad","role":"Performance Lead","brand":"Peak Outdoor","result":"SAMPLE · -19% CPA","avatar":"/images/clients/client-13.jpg","initial":"OH","sample":true},{"id":14,"offer":"Media Buying","quote":"Having the campaign plan and reporting in one rhythm made weekly decisions feel more grounded.","name":"Sofia Bennett","role":"Founder","brand":"Little Atlas Travel","result":"SAMPLE · +23% LEADS","avatar":"/images/clients/client-14.jpg","initial":"SB","sample":true},{"id":15,"offer":"Media Buying","quote":"The account structure was easier to understand, and we knew which audience and creative tests were live.","name":"Andre Lim","role":"E-commerce Manager","brand":"Mono Athletics","result":"SAMPLE · 2.4× ROAS","avatar":"/images/clients/client-15.jpg","initial":"AL","sample":true},{"id":16,"offer":"Influencer & Collabs","quote":"The creator shortlist felt aligned with our audience, and the collaboration brief gave everyone a clear start.","name":"Rhea Kapoor","role":"Partnerships Lead","brand":"Nectar Beauty","result":"SAMPLE · 8 CREATOR PARTNERS","avatar":"/images/clients/client-16.jpg","initial":"RK","sample":true},{"id":17,"offer":"Influencer & Collabs","quote":"The collaboration content sounded like the creators while still feeling unmistakably like our brand.","name":"Ben Foster","role":"Brand Manager","brand":"Trailhead Gear","result":"SAMPLE · 14 ASSETS","avatar":"/images/clients/client-17.jpg","initial":"BF","sample":true},{"id":18,"offer":"Influencer & Collabs","quote":"We had a smoother process from creator outreach through final content handoff and usage planning.","name":"Lana Reyes","role":"Social Director","brand":"Daybreak Drinks","result":"SAMPLE · 6 COLLABS","avatar":"/images/clients/client-18.jpg","initial":"LR","sample":true},{"id":19,"offer":"Community Management","quote":"Our replies became more timely and on-brand, and the team had a clearer way to surface audience questions.","name":"Dylan Park","role":"Community Manager","brand":"Good Tide Collective","result":"SAMPLE · 2× REPLIES","avatar":"/images/clients/client-19.jpg","initial":"DP","sample":true},{"id":20,"offer":"Community Management","quote":"The community felt more connected because conversations were being handled with a consistent voice.","name":"Amara Okafor","role":"Founder","brand":"Kindred Table","result":"SAMPLE · +34% COMMENTS","avatar":"/images/clients/client-20.jpg","initial":"AO","sample":true}];
function testimonialOrbitMarkup(){const ids=[1,6,9,13,19],cards=ids.map(id=>TESTIMONIALS.find(x=>x.id===id));return `<div class="testimonial-orbit" data-testimonial-orbit><div class="testimonial-orbit-stage" data-orbit-stage>${cards.map((item,index)=>`<article class="testimonial-card testimonial-orbit-card${index===0?" is-current":""}" role="button" tabindex="0" aria-label="Testimonial ${String(index+1).padStart(2,"0")} of 5 from ${item.name}. Select to feature." data-orbit-index="${index}"><div class="orbit-card-top"><span class="orbit-quote-mark">“</span><span class="orbit-index">${String(index+1).padStart(2,"0")} / 05</span><span class="orbit-offer">${item.offer.toUpperCase()}</span></div><p class="orbit-quote">${item.quote}</p><div class="orbit-card-bottom"><span class="orbit-avatar avatar-fallback"><span>${item.initial}</span></span><div class="orbit-client"><strong>${item.name}</strong><small>${item.role} · ${item.brand}</small></div><span class="orbit-result">${item.result}</span></div></article>`).join("")}</div><div class="orbit-controls"><button type="button" class="orbit-arrow" data-orbit-prev aria-label="Previous testimonial">←</button><span class="orbit-counter" aria-live="polite"><strong data-orbit-current>01</strong> / 05</span><button type="button" class="orbit-arrow" data-orbit-next aria-label="Next testimonial">→</button></div><p class="orbit-hint">Drag, tap a card, or use arrows · Hover to pause</p></div>`}
function clientLogoMarquee(){const logos=Array.from({length:20},(_,i)=>`<img src="clients%20logo/CLIENT%20${i+1}.png" alt="WS Media client logo ${i+1}" loading="lazy">`).join("");return `<section class="client-logo-marquee" aria-label="WS Media client logos"><div class="section-inner"><div class="eyebrow">In good company</div><div class="logo-marquee-window"><div class="logo-marquee-track"><div class="logo-marquee-group">${logos}</div><div class="logo-marquee-group" aria-hidden="true">${logos}</div></div></div></div></section>`}
function setupTestimonialOrbit(){if(window.__testimonialOrbitTimer){clearInterval(window.__testimonialOrbitTimer);window.__testimonialOrbitTimer=0}if(window.__testimonialOrbitFrame){cancelAnimationFrame(window.__testimonialOrbitFrame);window.__testimonialOrbitFrame=0}const root=document.querySelector("[data-testimonial-orbit]");if(!root)return;const stage=root.querySelector("[data-orbit-stage]"),cards=[...stage.querySelectorAll("[data-orbit-index]")],counter=root.querySelector("[data-orbit-current]");const state={rotationOffset:0,targetRotationOffset:0,velocity:0,pointerX:null,dragging:false,dragDistance:0,suppressClickUntil:0};const wrapAngle=n=>((n+180)%360+360)%360-180;function renderFrame(){const delta=state.targetRotationOffset-state.rotationOffset;state.velocity=(state.velocity+delta*.045)*.78;state.rotationOffset+=state.velocity;if(Math.abs(delta)<.025&&Math.abs(state.velocity)<.025){state.rotationOffset=state.targetRotationOffset;state.velocity=0;if(Math.abs(state.rotationOffset)>360){state.rotationOffset%=360;state.targetRotationOffset=state.rotationOffset}}const radius=Math.min(370,stage.clientWidth*.42),arcRise=Math.min(44,stage.clientHeight*.12);let front=0,frontDistance=Infinity;cards.forEach((card,index)=>{const degrees=state.rotationOffset+index*72,radians=degrees*Math.PI/180,depth=Math.cos(radians),x=Math.sin(radians)*radius,y=-arcRise*(1-depth),scale=.91+.09*Math.max(0,depth),opacity=.5+.5*((depth+1)/2),tilt=Math.max(-8,Math.min(8,Math.sin(radians)*8));card.style.transform=`translate(-50%,-50%) translate3d(${x}px,${y}px,${depth*130}px) rotate(${tilt}deg) scale(${scale})`;card.style.opacity=opacity.toFixed(3);card.style.filter=`brightness(${(.76+.24*opacity).toFixed(3)})`;const distance=Math.abs(wrapAngle(degrees));if(distance<frontDistance){frontDistance=distance;front=index}});cards.forEach((card,index)=>card.classList.toggle("is-current",index===front));counter.textContent=String(front+1).padStart(2,"0");window.__testimonialOrbitFrame=requestAnimationFrame(renderFrame)}function select(index){const base=-index*72;state.targetRotationOffset=base+360*Math.round((state.rotationOffset-base)/360)}function step(direction){state.targetRotationOffset+=direction===1?-72:72}root.addEventListener("click",event=>{if(event.target.closest("[data-orbit-next]")){step(1);return}if(event.target.closest("[data-orbit-prev]")){step(-1);return}const card=event.target.closest("[data-orbit-index]");if(card&&Date.now()>state.suppressClickUntil)select(Number(card.dataset.orbitIndex))});root.addEventListener("keydown",event=>{const card=event.target.closest("[data-orbit-index]");if(card&&(event.key==="Enter"||event.key===" ")){event.preventDefault();select(Number(card.dataset.orbitIndex));return}if(event.key==="ArrowRight")step(1);if(event.key==="ArrowLeft")step(-1)});stage.addEventListener("pointerdown",event=>{state.dragging=true;state.pointerX=event.clientX;state.dragDistance=0});stage.addEventListener("pointermove",event=>{if(!state.dragging||state.pointerX===null)return;const dx=event.clientX-state.pointerX;state.pointerX=event.clientX;const previousDistance=state.dragDistance;state.dragDistance+=Math.abs(dx);if(previousDistance<=7&&state.dragDistance>7)stage.setPointerCapture?.(event.pointerId);state.rotationOffset+=dx*.22;state.targetRotationOffset=state.rotationOffset;state.velocity=0});const finishDrag=()=>{if(!state.dragging)return;state.dragging=false;state.pointerX=null;if(state.dragDistance>7){state.suppressClickUntil=Date.now()+450;state.targetRotationOffset=Math.round(state.rotationOffset/72)*72}};stage.addEventListener("pointerup",finishDrag);stage.addEventListener("pointercancel",finishDrag);stage.addEventListener("pointerleave",finishDrag);renderFrame();if(!window.matchMedia("(prefers-reduced-motion: reduce)").matches){window.__testimonialOrbitTimer=setInterval(()=>{if(root.matches(":hover")||root.contains(document.activeElement)||document.hidden)return;state.targetRotationOffset-=72},7600)}}
function serviceCards() {
  return services.map(service => `
    <article class="pricing-card service-card">
      <span class="pricing-tag">${service.tag} · FLEXIBLE SCOPE</span>
      <h4 class="service-card-title">
        <a target="_blank" rel="noopener" class="service-card-link" href="#${service.slug}">${service.title}</a>
      </h4>
      <p>${service.summary}</p>
      <p>${service.scope.description}</p>
      <ul>${service.scope.items.map(item => `<li>${item}</li>`).join("")}</ul>
      <div class="pricing-bottom"><strong>Custom scope</strong></div>
    </article>
  `).join("");
}

function mosaic(){const cards=[{title:"Cut with intention",tag:"VIDEO EDITING",image:PHOTO.edit,to:"video-editor"},{title:"Made for the feed",tag:"ORGANIC CONTENT",image:PHOTO.creator,to:"organic-content"},{title:"Creative that converts",tag:"META CREATIVE",image:PHOTO.campaign,to:"meta-creatives"},{title:"Stories in motion",tag:"BRAND STORY",image:PHOTO.studio,to:"video-editor"}];return cards.map(x=>`<a target="_blank" rel="noopener" class="mosaic-card" href="#${x.to}"><img src="${x.image}" alt="${x.tag.toLowerCase()} sample project"><div class="mosaic-label"><small>${x.tag}</small><b>${x.title}</b></div></a>`).join("")}
const portfolio = [
  {
    client: "Max Perzon",
    before: {id: "A4n_yjhrajI", title: "7 Millionaire Skills I Wish I Knew At 20"},
    after: {id: "hYW6m-BjmTg", title: "I Started SMMA With $0 Using AI - Ep. 1"},
  },
  {
    client: "Luke Alexander",
    before: {id: "E3P6I2keVfY", title: "Three Things GUARANTEED To Help You Close More Deals"},
    after: {id: "rK1pTHh-dbI", title: "These 7 things will make you a millionaire"},
  },
  {
    client: "Moving to Chicago Suburbs",
    before: {id: "I0mBeKreIrI", title: "October Real Estate Market Update: Prices, Inventory, and Predictions - Move to Arlington Heights"},
    after: {id: "mnfCvg8DK_o", title: "Find Your Dream Small Town in Beautiful Long Grove Illinois"},
  },
];

const creators = [
  {name: "Max Perzon", handle: "max.perzon", image: "ca7be5_4fdf48b19ba74edd8b5d3910c43ae4cc~mv2.jpg", reel: "C3Nwfe1NClf"},
  {name: "Alex Heiden", handle: "nocode.alex", image: "ca7be5_18f996f3e482403ab937088a66724f46~mv2.jpg", reel: "CxaoB2DrHLb"},
  {name: "Hassan Khan", handle: "hasskhan_", image: "ca7be5_dbc9f37902644411a51ff2fc72a05c12~mv2.jpg", reel: "CsWYG9ytHnB"},
];
const umarShort = {id: "-z2BbzqbRFw", title: "2 Reasons Why You're NOT Making Money as a Day Trader"};
const umarPortrait = "ca7be5_1cf067bb002f4e979e7645d1ffc730a1~mv2.jpg";
const caseStudyPoster = "images/ws-media-case-study-poster.webp";
const wixImage = "https://static.wixstatic.com/media/";

function youtubePoster(clip, poster = `https://i.ytimg.com/vi/${clip.id}/hqdefault.jpg`) {
  return `<div class="youtube-preview">
    <button class="video-preview-button" type="button" data-youtube-id="${clip.id}" data-video-title="${clip.title}" aria-label="Play ${clip.title}">
      <img src="${poster}" alt="" loading="lazy">
      <span class="video-play-icon" aria-hidden="true"></span>
    </button>
  </div>`;
}

function workCards() {
  return portfolio.map(({client, before, after}) => `
    <section class="portfolio-pair">
      <h3>${client}</h3>
      <div class="portfolio-pair-grid">
        ${[before, after].map((clip, index) => `
          <article class="portfolio-clip">
            ${youtubePoster(clip)}
            <div class="portfolio-caption">
              <span class="portfolio-stage">${index === 0 ? "Before" : "After"}</span>
              <h4><a target="_blank" rel="noopener" href="https://www.youtube.com/watch?v=${clip.id}">${clip.title}</a></h4>
            </div>
          </article>`).join("")}
      </div>
    </section>`).join("");
}

function creatorsSection() {
  return `<section class="section creators-section" id="creators" aria-labelledby="creators-title">
    <div class="section-inner">
      <h2 class="section-heading" id="creators-title">Our Creators</h2>
      <div class="creator-grid">
        ${creators.map(person => `
          <article class="creator-card">
            <a class="creator-profile" href="https://www.instagram.com/${person.handle}/" target="_blank" rel="noopener">
              <img src="${wixImage}${person.image}" width="72" height="72" alt="" loading="lazy">
              <h3>${person.name}</h3>
              <span>@${person.handle}</span>
            </a>
            <a class="creator-link" href="https://www.instagram.com/reel/${person.reel}/" target="_blank" rel="noopener">Watch on Instagram</a>
          </article>`).join("")}
        <article class="creator-card creator-short">
          ${youtubePoster(umarShort, wixImage + umarPortrait)}
          <h3>Umar Ashraf</h3>
          <a class="creator-link" href="https://www.youtube.com/shorts/${umarShort.id}" target="_blank" rel="noopener">${umarShort.title}</a>
        </article>
      </div>
    </div>
  </section>`;
}
function caseCards(){return caseStudies.map(c=>`<article class="case-card"><small>${c.type} · CASE STUDY PREVIEW</small><h3>${c.title}</h3><p>${c.body}</p><div class="case-placeholder">RESULT PLACEHOLDER<strong>${c.result}</strong></div></article>`).join("")}
function whyCards(){return [{n:"01",title:"Creative with a clear point of view",text:"Every edit, post, and ad starts with the story your brand needs to tell."},{n:"02",title:"One connected creative partner",text:"Video editing, organic content, and Meta creative work together under one roof."},{n:"03",title:"Built around your real workflow",text:"We align on briefs, feedback, and delivery so content fits the way your team works."}].map(x=>`<article class="why-card"><span>${x.n} / WS MEDIA</span><h3>${x.title}</h3><p>${x.text}</p></article>`).join("")}
function processCards(){return [{n:"01",title:"Discover",text:"We learn about your brand, audience, goals, existing content, and what success should look like."},{n:"02",title:"Strategize",text:"We agree on creative direction, formats, deliverables, and a practical approval workflow."},{n:"03",title:"Create & deliver",text:"Our team edits and develops the agreed assets, then prepares them for your selected channels."},{n:"04",title:"Review & refine",text:"We gather feedback, make the agreed refinements, and use learnings to guide the next round."}].map(x=>`<article class="process-card"><span>${x.n}</span><h3>${x.title}</h3><p>${x.text}</p></article>`).join("")}
const audienceRoles = ['Realtor', 'Agency', 'E-Commerce', 'Startup', 'Coach', 'Podcaster', 'YouTuber'];

function comparisonBlock() {
  const other = ["Separate vendors for edits, social, and paid creative", "Slow handoffs and unclear feedback loops", "One-off assets without a connected content plan"];
  const ws = ["One creative partner across video, organic, and Meta", "Clear briefs, feedback, and delivery workflow", "Creative shaped around your goals and next move"];
  return `<section class="section comparison-section" id="why-work-with-us">
    <div class="section-inner">
      <div class="eyebrow">The WS Media difference</div>
      <h2 class="section-heading">But, why would you want<br>to work with us?</h2>
      <div class="audience-loop" data-audience-loop>
        <p class="audience-static">Are you a ${audienceRoles.join(", ")}?</p>
        <p class="audience-motion" aria-hidden="true">Are you a
          <span class="audience-roles">${audienceRoles.map(role => `<span>${role}?</span>`).join("")}</span>
        </p>
        <button type="button" class="audience-pause" aria-label="Pause rotating text">Pause</button>
      </div>
      <div class="comparison-grid">
        <article class="comparison-card">
          <h3>Other Agencies</h3>
          <ul>${other.map(item => `<li><span class="comparison-mark">×</span>${item}</li>`).join("")}</ul>
        </article>
        <article class="comparison-card comparison-ws">
          <h3>WS Media</h3>
          <ul>${ws.map(item => `<li><span class="comparison-mark">✓</span>${item}</li>`).join("")}</ul>
        </article>
      </div>
      <details class="comparison-disclosure">
        <summary>How do the three services work together?</summary>
        <p>We use one creative direction across video editing, organic content, and Meta creatives. A strong idea can become a video, a recurring social format, and ad variations your team can test.</p>
      </details>
    </div>
  </section>`;
}

function heroWords(line) {
  return line.split(" ").map(word => `<span class="hero-word">${word}</span>`).join(" ");
}

function bookingDateOptions() {
  const singaporeDate = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Singapore",
    year: "numeric",
    month: "numeric",
    day: "numeric",
  });
  const {year, month, day} = Object.fromEntries(
    singaporeDate.formatToParts(new Date()).map(({type, value}) => [type, value])
  );
  const date = new Date(Date.UTC(Number(year), Number(month) - 1, Number(day)));
  const shortLabel = new Intl.DateTimeFormat("en-US", {
    timeZone: "UTC", weekday: "short", month: "short", day: "2-digit",
  });
  const fullLabel = new Intl.DateTimeFormat("en-US", {
    timeZone: "UTC", dateStyle: "full",
  });
  const options = [];

  while (options.length < 6) {
    date.setUTCDate(date.getUTCDate() + 1);
    if ([0, 6].includes(date.getUTCDay())) continue;
    const parts = Object.fromEntries(
      shortLabel.formatToParts(date).map(({type, value}) => [type, value])
    );
    options.push(`<button class="date-option" type="button" data-date
      aria-label="${fullLabel.format(date)}" aria-pressed="false">
      <small>${parts.weekday}</small><strong>${parts.day}</strong><small>${parts.month}</small>
    </button>`);
  }
  return options.join("");
}

function bookingSection(anchor = "contact") {
  return `<section class="section booking-section" id="${anchor}" aria-labelledby="strategy-call-title" tabindex="-1">
    <div class="section-inner">
      <div class="eyebrow">30-minute strategy call</div>
      <div class="booking-layout">
        <div class="booking-pitch">
          <h2 class="section-heading" id="strategy-call-title">Let’s scale<br><span class="booking-yellow">your growth.</span></h2>
          <p class="section-lead">Bring your goals, current content workflow, and biggest growth opportunity. We’ll talk through the right next step for your team.</p>
          <article class="booking-quote">
            <span>CLIENT QUOTE · SAMPLE</span>
            <blockquote>“An early strategy conversation helped us see what to prioritize and what creative to test next.”</blockquote>
            <strong>Illustrative client</strong><small>Sample brand story</small>
          </article>
        </div>
        <div class="booking-widget" id="booking-picker">
          <div class="booking-widget-head">
            <div><span>WS MEDIA · CONSULTATION</span><h3>30-Min Strategy Call</h3></div>
            <span class="timezone-label">SINGAPORE TIME · SGT</span>
          </div>
          <fieldset class="booking-choice">
            <legend class="picker-label">Choose a preferred date</legend>
            <div class="booking-dates">${bookingDateOptions()}</div>
          </fieldset>
          <fieldset class="booking-choice">
            <legend class="picker-label">Choose a time</legend>
            <div class="booking-times">
              ${["10:00 AM", "1:30 PM", "3:00 PM", "4:30 PM"].map(time =>
                `<button class="time-option" type="button" data-time="${time}" aria-pressed="false" disabled>${time}</button>`
              ).join("")}
            </div>
          </fieldset>
          <div class="booking-goals-field">
            <label for="project-brief">Project brief / goals</label>
            <div class="border-trail-textarea">
              <textarea id="project-brief" rows="5" required
                placeholder="Tell us about your project, goals, audience, or the help you need…"></textarea>
            </div>
          </div>
          <p class="booking-hint">Your selected time is a request. We’ll confirm availability by email.</p>
          <button class="button button-hot booking-submit" type="button" disabled>Continue to scheduling</button>
          <p class="booking-feedback" role="status"></p>
        </div>
      </div>
    </div>
  </section>`;
}

function setupBookingPicker() {
  const picker = document.getElementById("booking-picker");
  if (!picker) return;

  const dates = [...picker.querySelectorAll("[data-date]")];
  const times = [...picker.querySelectorAll("[data-time]")];
  const brief = picker.querySelector("#project-brief");
  const submit = picker.querySelector(".booking-submit");
  const feedback = picker.querySelector(".booking-feedback");
  const choose = (options, selected) => options.forEach(option =>
    option.setAttribute("aria-pressed", String(option === selected))
  );

  dates.forEach(date => date.addEventListener("click", () => {
    choose(dates, date);
    choose(times, null);
    times.forEach(time => { time.disabled = false; });
    submit.disabled = true;
  }));

  times.forEach(time => time.addEventListener("click", () => {
    choose(times, time);
    submit.disabled = false;
  }));

  brief.addEventListener("input", () => brief.setCustomValidity(""));
  submit.addEventListener("click", () => {
    const date = picker.querySelector('[data-date][aria-pressed="true"]');
    const time = picker.querySelector('[data-time][aria-pressed="true"]');
    const goals = brief.value.trim();
    brief.setCustomValidity(goals ? "" : "Enter your project brief or goals.");
    if (!date || !time || !brief.reportValidity()) return;

    const schedulingTab = window.open("", "_blank");
    if (!schedulingTab) {
      feedback.textContent = "Allow pop-ups for this site to open scheduling in a new tab.";
      return;
    }

    feedback.textContent = "";
    schedulingTab.opener = null;
    if (bookingUrl.href === bookingPreviewUrl.href) {
      try {
        schedulingTab.sessionStorage.setItem("ws-media-booking-preferences", JSON.stringify({
          date: date.getAttribute("aria-label"),
          time: `${time.dataset.time} SGT`,
          goals,
        }));
      } catch {
        // Scheduling still opens when browser storage is unavailable.
      }
    }
    const loadingUrl = new URL(bookingPreviewUrl);
    loadingUrl.searchParams.set("loading", "1");
    schedulingTab.location.replace(loadingUrl.href);
  });
}
function faqItems(){return [{q:"What’s included in the META Machine?",a:"The META Machine is a connected paid-social creative workflow: hook and concept development, video or static ad assets, creative variations for testing, and learnings to guide the next round. Media buying scope is agreed separately where needed."},{q:"What’s included in the Organic Content Machine?",a:"It brings content direction, repeatable social formats, creator-led production or editing, and repurposing into a practical publishing-ready workflow shaped around your brand and audience."},{q:"Do you handle media buying and backup ad accounts?",a:"Media buying can be included when it is part of the agreed scope. We can discuss account access and continuity planning, including backup ad account options where available and policy-compliant. Account ownership, platform approvals, and access remain subject to Meta’s rules and your business setup."},{q:"How many video editing outputs can we plan for each month?",a:"Video editing can be scoped around 44–66 outputs per month. The final count depends on source footage, complexity, formats and versions, review turnaround, and the agreed deliverables."},{q:"How long does onboarding take?",a:"We confirm the onboarding timeline after reviewing your scope, materials, and account access. Kickoff covers goals, audience, brand references, deliverables, access, and the feedback workflow so the team knows what is needed before production begins."}].map(x=>`<details class="faq-item"><summary>${x.q}<span>+</span></summary><p>${x.a}</p></details>`).join("")}
function articles(){const a=[{image:PHOTO.studio,tag:"VIDEO",title:"What makes a short-form edit worth watching?",body:"A quick look at pacing, hooks, and the choices that help a story land in a crowded feed."},{image:PHOTO.social,tag:"ORGANIC",title:"Build a content rhythm you can actually keep",body:"A practical starting point for showing up consistently without making every post from scratch."},{image:PHOTO.meta,tag:"CREATIVE",title:"Why creative testing starts with the idea",body:"A useful campaign needs more than variations. It needs clear creative directions worth testing."}];return a.map(x=>`<article class="journal-card"><div class="journal-image"><img src="${x.image}" alt="Article illustration"></div><div class="journal-content"><small>${x.tag} · WS MEDIA NOTES</small><h3>${x.title}</h3><p>${x.body}</p><a target="_blank" rel="noopener" href="#contact">Read the note</a></div></article>`).join("")}
const featureVideoTitle = "Attention is earned.";
const testimonialTitle = "What They Say About WS Media";

function wixVideoPlayer(label, url, poster) {
  return `<div data-wix-video>
    <div class="sales-video-player">
      <video controls muted playsinline preload="metadata" data-autoplay-in-view aria-label="${label}" src="${url}" poster="${poster}"></video>
    </div>
    <p class="vsl-fallback" role="status" hidden>The video could not load. <a class="creator-link" href="${url}" target="_blank" rel="noopener">Open original video</a></p>
  </div>`;
}

function viralVideoSection() {
  const poster = wixImage + "cdd8bd_fac5aca9905b432e9f7971a8daddd9b9f000.jpg/v1/fill/w_960,h_540,al_c,q_80/viral.jpg";
  return `<section class="section sales-video-section" id="sales-video" aria-labelledby="sales-video-title">
    <div class="section-inner sales-video-inner">
      <h2 class="section-heading" id="sales-video-title">${featureVideoTitle}</h2>
      ${wixVideoPlayer(featureVideoTitle, SITE_CONFIG.viralVideoUrl, poster)}
      <p class="section-lead feature-video-description">A strong hook gets people watching. A clear story gives them a reason to stay.</p>
      <a class="button button-hot sales-video-booking" href="#contact">Book a Call</a>
    </div>
  </section>`;
}

function testimonialVideo() {
  const poster = wixImage + "15d6ed_ee145bddca3c4194a1a4edce396891fef000.jpg/v1/fill/w_960,h_540,al_c,q_80/testimonial.jpg";
  return `<div class="testimonial-video">
    <h3 class="sales-video-label">${testimonialTitle}</h3>
    ${wixVideoPlayer(testimonialTitle, SITE_CONFIG.testimonialVideoUrl, poster)}
  </div>`;
}

function closingPreview() {
  return `<figure class="closing-preview">
    <img src="${caseStudyPoster}" width="600" height="336" alt="WS Media presenter speaking in front of a laptop" loading="lazy">
    <figcaption>
      <span>Case study preview</span>
      <button class="button" type="button" data-case-study-preview>Play preview</button>
    </figcaption>
  </figure>`;
}

function home(){return `<section class="hero" id="home"><video class="hero-video" muted loop playsinline data-autoplay-in-view poster="${PHOTO.hero}" aria-hidden="true"><source src="https://videos.pexels.com/video-files/3209828/3209828-hd_1920_1080_25fps.mp4" type="video/mp4"></video><div class="hero-video-shade"></div><div class="hero-top hero-glass"><div class="hero-kicker">A CREATIVE CONTENT STUDIO BUILT TO SHAPE YOURS.</div><h1 aria-label="We live in a world shaped by perception.">${heroWords("We live in a world")}<br>${heroWords("shaped by")} <span class="hero-word gradient">perception.</span></h1><p class="hero-intro">Get in, we're going <em>viral.</em></p><p class="hero-copy">A video and content partner for brands, creators, and marketing teams that refuse to blend in. Video editing, organic content, and Meta creatives—built as one creative system.</p><div class="hero-actions"><a class="button button-hot" href="#contact">Book a call</a><a target="_blank" rel="noopener" class="hero-work-link" href="#work">See the work</a></div><div class="review-strip"><span class="stars">★★★★★</span><span>Trusted by marketing teams, startups & creators</span><span class="review-source">WORKING WORLDWIDE</span></div></div><div class="work-mosaic">${mosaic()}</div><div class="hero-scroll">SCROLL TO EXPLORE</div><a target="_blank" rel="noopener" class="scroll-cue" href="#sales-video" aria-label="Scroll down to explore"><span>SCROLL TO EXPLORE</span></a></section>
${viralVideoSection()}
<section class="agency-statement scroll-highlight-statement" id="brand-statement" aria-label="Our work is shaped around three core pillars: video editing, organic content, and Meta creatives—a connected creative system that helps your brand show up consistently and with intention."><p class="scroll-highlight-copy" aria-hidden="true">${ScrollHighlightStatement("Our work is shaped around three core pillars: video editing, organic content, and Meta creatives—a connected creative system that helps your brand show up consistently and with intention.")}</p></section>
<nav class="section-jump" aria-label="Explore page sections">
  <a class="jump-home" href="#home">Home</a>
  <div class="jump-links">
    <span class="jump-label">JUMP TO</span>
    <a target="_blank" rel="noopener" href="#services">Services</a>
    <a target="_blank" rel="noopener" href="#work">Work</a>
    <a target="_blank" rel="noopener" href="#why-us">Why WS</a>
    <a target="_blank" rel="noopener" href="#process">Process</a>
    <a target="_blank" rel="noopener" href="#testimonials">Testimonials</a>
    <a target="_blank" rel="noopener" href="#faq">FAQ</a>
  </div>
  <div class="jump-tools">
    <div data-theme-toolbar></div>
    <button class="menu-toggle jump-menu" type="button" aria-label="Open menu" aria-expanded="false" aria-controls="site-menu"><span>Menu</span><i aria-hidden="true"><b></b><b></b></i></button>
  </div>
</nav>
<section class="section capabilities" id="services">
  <div class="section-inner">
    <div class="eyebrow">What we do</div>
    <div class="section-head-row">
      <div>
        <h2 class="section-heading">Video, social and paid creative,<br>built as one system.</h2>
        <p class="section-lead">No hiring bottlenecks. No juggling five vendors. Bring your next idea to a creative team that can take it from raw footage to campaign-ready content.</p>
      </div>
      <a class="button button-hot services-booking" href="#contact">Book a Call</a>
    </div>
    <div class="service-options" id="pricing">
      <div class="eyebrow">Ways to work together</div>
      <h3 class="service-options-title">The right creative support for your next move.</h3>
      <p class="section-lead">Every project is scoped around its deliverables. Tell us what you need and we’ll map the right approach.</p>
      <div class="pricing-grid">${serviceCards()}</div>
    </div>
  </div>
</section>
<section class="section work-section" id="work"><div class="section-inner"><div class="section-head-row"><div><div class="eyebrow">Selected work</div><h2 class="section-heading">We tackle every project<br>like the next one we'll brag about.</h2></div><a class="button" href="#contact">Book a call</a></div><div class="portfolio-grid">${workCards()}</div></div></section>
${creatorsSection()}
<section class="section case-section"><div class="section-inner"><div class="eyebrow">Designed to be seen. Built to win.</div><h2 class="section-heading">Good creative should<br>make a difference.</h2><p class="section-lead">A few examples of how WS Media work can be presented. Add approved projects and verified outcomes to turn these previews into full case studies.</p><div class="case-grid">${caseCards()}</div></div></section>
<section class="section why-section" id="why-us"><div class="section-inner"><div class="eyebrow">Why WS Media</div><h2 class="section-heading">A creative partner<br>that gets in the work.</h2><p class="section-lead">Thoughtful creative, clear collaboration, and content built to serve the work your team is already doing.</p><div class="why-grid">${whyCards()}</div></div></section>
<section class="section process-section" id="process"><div class="section-inner"><div class="eyebrow">Our process</div><h2 class="section-heading">From first brief<br>to ready-to-post.</h2><p class="section-lead">A simple, collaborative workflow keeps projects focused from the first conversation through final delivery.</p><div class="process-grid">${processCards()}</div></div></section>
${comparisonBlock()}
<section class="section testimonials-section" id="testimonials"><div class="section-inner"><div class="eyebrow">From our partners</div><h2 class="section-heading">Good work is better<br>when it’s collaborative.</h2>${testimonialVideo()}<p class="section-lead">Illustrative sample quotes and metrics for layout only. Replace with approved client stories before publishing.</p>${testimonialOrbitMarkup()}<p class="placeholder-note">Illustrative sample testimonials and metrics for layout only. Replace with approved client stories and verified results before publishing.</p></div></section>
${clientLogoMarquee()}
${bookingSection()}
<section class="section faq-section" id="faq"><div class="section-inner faq-layout"><div><div class="eyebrow">FAQ</div><h2 class="section-heading">A few things<br>you might be wondering.</h2><p class="section-lead">Still have a question? Get in touch and tell us what you’re planning.</p><a target="_blank" rel="noopener" class="button" href="#contact">Ask us directly</a></div><div class="faq-list">${faqItems()}</div></div></section>
<section class="section agency-section" id="about"><div class="section-inner agency-layout">${closingPreview()}<div class="agency-copy"><div class="eyebrow">Who we are</div><h2 class="section-heading">Been there.<br>Seen it all.<br><span class="gradient">Done that.</span></h2><p>Good content is a team sport. We bring editors and creative minds together to help brands, agencies, and creators produce better work—without the extra hires, delays, or guesswork.</p><p>From the first brief to the final export, we keep the process thoughtful, collaborative, and focused on the story your audience needs to see.</p><div class="agency-location">WS MEDIA · CREATIVE PARTNER TO THE NEXT BIG THING</div></div></div></section>
<section class="section journal"><div class="section-inner"><div class="section-head-row"><div><div class="eyebrow">The Hub · Notes from the studio</div><h2 class="section-heading">What we're<br>thinking about.</h2></div><a target="_blank" rel="noopener" class="button" href="#services">Explore our approach</a></div><div class="journal-grid">${articles()}</div></div></section>`}
function subpage(s){const bookingAnchor = `${s.slug}?section=contact`;return `<section class="page-hero"><div><div class="eyebrow">WS Media · ${s.tag}</div><h1>${s.title}<br><span class="gradient">${s.titleEnd}</span></h1><p>${s.summary}</p><div class="hero-actions"><a class="button button-hot" href="#${bookingAnchor}">Book a call</a><a target="_blank" rel="noopener" class="hero-work-link" href="#${s.slug}?section=service-work">See the work</a></div></div><div class="page-image"><img src="${s.image}" alt="${s.title} example"><span class="page-image-label">${s.tag} · WS MEDIA</span></div></section><section class="agency-statement scroll-highlight-statement" aria-label="${s.intro} Built around your brand, audience, and next move."><p class="scroll-highlight-copy" aria-hidden="true">${ScrollHighlightStatement(s.intro, "Built around your brand, audience, and next move.")}</p></section><section class="section capabilities" id="results"><div class="section-inner"><div class="eyebrow">The approach</div><h2 class="section-heading">Creative with a reason<br>behind every frame.</h2><p class="section-lead">A clear process keeps good work moving. We align on the story, shape the creative, then deliver it ready for the places your audience spends time.</p><div class="capability-list">${s.offers.map((x,i)=>`<article class="capability"><div class="capability-title">0${i+1} / ${x.split(" ").slice(0,3).join(" ")}</div><div class="capability-copy">${x}. Tailored to your voice, goals, and the way your audience watches and responds.</div><div class="capability-items"><span>${s.tag}</span><span>CREATIVE DELIVERY</span></div></article>`).join("")}</div><div class="page-results" id="service-work">${[s.image,PHOTO.creator,PHOTO.campaign].map((img,i)=>`<div class="page-result"><img src="${img}" alt="${s.title} portfolio placeholder ${i+1}"><span>Portfolio example · ${String(i+1).padStart(2,"0")}</span></div>`).join("")}</div><p class="placeholder-note">Sample work preview · Replace with approved project images, case studies, and verified outcomes.</p></div></section><section class="cta-section"><div class="eyebrow">Your next move starts here</div><h2 class="section-heading">Ready to make it<br><span class="gradient">count?</span></h2><p>Talk with us about your goals and see how ${s.title.toLowerCase()} can fit your content system.</p><a class="button button-hot" href="#${bookingAnchor}">Book a call</a></section>${bookingSection(bookingAnchor)}`}
function setupProcessSpotlight(){if(window.__processSpotlightTimer){clearInterval(window.__processSpotlightTimer);window.__processSpotlightTimer=0}const grid=document.querySelector(".process-grid");if(!grid)return;const cards=[...grid.querySelectorAll(".process-card")];if(!cards.length)return;const reduced=window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;let active=0,hovered=-1;function idle(index){active=index;cards.forEach((card,i)=>{card.classList.toggle("is-spotlight",i===index);card.classList.remove("is-hovered","is-next-hovered")})}function hover(index){hovered=index;cards.forEach((card,i)=>{card.classList.toggle("is-hovered",i===index);card.classList.remove("is-spotlight","is-next-hovered")});if(index>0)cards[index-1].classList.add("is-next-hovered");else if(cards[0])cards[0].classList.add("is-next-hovered")}function clearHover(){if(hovered!==-1){hovered=-1;idle(active)}}function followPointer(event){const card=event.target.closest(".process-card");if(!card||!grid.contains(card)){clearHover();return}const index=cards.indexOf(card);if(index<0)return;if(hovered!==index)hover(index);const rect=card.getBoundingClientRect();card.style.setProperty("--spot-x",`${event.clientX-rect.left}px`);card.style.setProperty("--spot-y",`${event.clientY-rect.top}px`)}grid.addEventListener("pointermove",followPointer);grid.addEventListener("pointerleave",clearHover);grid.addEventListener("focusin",event=>{const card=event.target.closest(".process-card");if(card)hover(cards.indexOf(card))});grid.addEventListener("focusout",event=>{if(!grid.contains(event.relatedTarget))clearHover()});idle(0);if(!reduced){window.__processSpotlightTimer=setInterval(()=>{if(hovered!==-1||grid.contains(document.activeElement)||document.hidden)return;const rect=grid.getBoundingClientRect();if(rect.bottom<=0||rect.top>window.innerHeight)return;idle((active+1)%cards.length)},2400)}}
function render(service) {
  const app = document.getElementById("app");
  app.innerHTML = service ? subpage(service) : home();
  document.getElementById("year").textContent = new Date().getFullYear();
  document.querySelectorAll(".section-jump a").forEach(link => link.addEventListener("click", closeMenu));
  setupScrollReveal();
  setupScrollHighlightStatements();
  setupBookingPicker();
  setupVideoPlayers(app);
  setupTestimonialOrbit();
  setupProcessSpotlight();
  setupPageEffects(app);
}
function ScrollHighlightStatement(firstSentence, brandLine = "") {
  const words = (text, className) => text.split(/(\s+)/).filter(Boolean).map(
    part => /^\s+$/.test(part) ? part : `<span class="${className}">${part}</span>`
  ).join("");
  return words(firstSentence, "scroll-highlight-word") +
    (brandLine ? ` ${words(brandLine, "scroll-highlight-word scroll-highlight-brand")}` : "");
}
function setupScrollHighlightStatements(){const update=()=>{const vh=window.innerHeight||1;document.querySelectorAll(".scroll-highlight-statement").forEach(section=>{const rect=section.getBoundingClientRect(),words=section.querySelectorAll(".scroll-highlight-word"),center=rect.top+rect.height/2,progress=Math.max(0,Math.min(1,(vh+rect.height/2-center)/(vh*.45+rect.height/2)));words.forEach((word,index)=>{const local=Math.max(0,Math.min(1,progress*words.length-index));word.style.setProperty("--word-progress",(local*100).toFixed(1)+"%")})})};if(!window.__wsScrollHighlightBound){let scheduled=false;const schedule=()=>{if(scheduled)return;scheduled=true;requestAnimationFrame(()=>{scheduled=false;update()})};window.addEventListener("scroll",schedule,{passive:true});window.addEventListener("resize",schedule);window.__wsScrollHighlightBound=true}update()}
function setupTextRevert(){const el=document.querySelector(".reveal-text");if(!el)return;const reduced=window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;if(reduced)return;let timer;const observer=new IntersectionObserver(entries=>{for(const entry of entries){if(entry.isIntersecting){el.classList.remove("is-hidden");el.classList.add("is-visible");clearTimeout(timer);timer=setTimeout(()=>{el.classList.remove("is-visible");el.classList.add("is-hidden")},2600)}else{clearTimeout(timer);el.classList.remove("is-visible");el.classList.add("is-hidden")}}},{threshold:.3});observer.observe(el);el.addEventListener("click",()=>{clearTimeout(timer);el.classList.remove("is-hidden");el.classList.add("is-visible");timer=setTimeout(()=>{el.classList.remove("is-visible");el.classList.add("is-hidden")},2600)})}
function setupScrollReveal(){const targets=document.querySelectorAll("#app > section:not(.hero)");const reduced=window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;if(reduced||!("IntersectionObserver" in window)){targets.forEach(el=>el.classList.add("is-in-view"));return}const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add("is-in-view");observer.unobserve(entry.target)}}),{threshold:.12,rootMargin:"0px 0px -35px 0px"});targets.forEach((el,i)=>{el.classList.add("scroll-reveal");el.style.setProperty("--reveal-delay",`${Math.min(i*55,220)}ms`);observer.observe(el)})}
const menuPanel = document.getElementById("site-menu");
const menuClose = menuPanel.querySelector(".menu-close");
let menuOpener;

function openMenu(toggle) {
  menuOpener = toggle;
  menuPanel.inert = false;
  menuPanel.classList.add("open");
  menuPanel.setAttribute("aria-hidden", "false");
  document.querySelectorAll(".menu-toggle").forEach(button => button.setAttribute("aria-expanded", "true"));
  menuClose.focus({preventScroll: true});
}

function closeMenu() {
  if (!menuPanel.classList.contains("open")) return;
  const returnFocus = menuPanel.contains(document.activeElement);
  menuPanel.classList.remove("open");
  menuPanel.setAttribute("aria-hidden", "true");
  menuPanel.inert = true;
  document.querySelectorAll(".menu-toggle").forEach(button => button.setAttribute("aria-expanded", "false"));
  if (returnFocus && menuOpener?.isConnected) menuOpener.focus({preventScroll: true});
  menuOpener = null;
}

let renderedService;

function readRoute(hash) {
  const [slug, query] = hash.replace(/^#\/?/, "").split("?", 2);
  const service = services.find(item => item.slug === slug) ?? null;
  const section = service ? new URLSearchParams(query).get("section") : slug;
  return {service, section};
}

function handleRouteChange() {
  const {service, section} = readRoute(location.hash);
  const pageChanged = service !== renderedService;
  if (pageChanged) {
    render(service);
    renderedService = service;
  }

  closeMenu();
  if (!pageChanged && !service) return;

  if (section && section !== "home") {
    const destination = document.getElementById(location.hash.slice(1)) ?? document.getElementById(section);
    destination?.scrollIntoView({behavior: pageChanged ? "instant" : "auto", block: "start"});
  } else {
    window.scrollTo({top: 0, behavior: "instant"});
  }
}

document.addEventListener("click", event => {
  const toggle = event.target.closest(".menu-toggle");
  if (toggle) openMenu(toggle);
});
menuClose.addEventListener("click", closeMenu);
menuPanel.querySelectorAll("nav a").forEach(link => link.addEventListener("click", closeMenu));
menuPanel.addEventListener("keydown", event => {
  if (event.key === "Escape") closeMenu();
});
window.addEventListener("hashchange", handleRouteChange);
setupSiteEffects();
handleRouteChange();
setupTextRevert();
